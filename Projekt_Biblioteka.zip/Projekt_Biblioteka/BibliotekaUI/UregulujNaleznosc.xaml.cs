﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BibliotekaUI
{

    public partial class UregulujNaleznosc : Window
    {
        private KontoBiblioteczne kontobiblioteczne;
        private Filia filiaBiblioteka;
        public UregulujNaleznosc(KontoBiblioteczne konto, Filia filia)
        {
            InitializeComponent();
            kontobiblioteczne = konto;
            filiaBiblioteka = filia;
            PokazWypozyczenia();
        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
            kontoOkno.Show();
            this.Close();

        }

        private void PokazWypozyczenia()
        {
            List<Wypozyczenie> dostepneKsiazki = kontobiblioteczne.listaWypozyczenKonta.Where(w => w.WysokoscKary() > 0).ToList();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych należności do uregulowania w tej chwili.");
            }
            else
            {
                ComboBoxNaleznosc.ItemsSource = dostepneKsiazki;
            }
        }

        private void Naleznosc(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is Wypozyczenie w)
            {
                w.UregulujNaleznosci();
                w.dataZwrotu = DateTime.Now.AddDays(1);
                MessageBox.Show("Uregulowano należności. Masz jeden dzień na zwrot książki. W przeciwnym wypadku należności za książkę zostaną naliczone ponownie.");
                KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
                kontoOkno.Show();
                this.Close();
            }
        }
    }
}
