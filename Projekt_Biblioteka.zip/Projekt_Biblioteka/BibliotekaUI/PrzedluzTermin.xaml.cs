﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BibliotekaUI
{

    public partial class PrzedluzTermin : Window
    {
        private KontoBiblioteczne kontobiblioteczne;
        private Filia filiaBiblioteka;
        public PrzedluzTermin(KontoBiblioteczne konto, Filia filia)
        {
            InitializeComponent();
            kontobiblioteczne = konto;
            filiaBiblioteka = filia;
            PokazWypozyczenia();
        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
            kontoOkno.Show();
            this.Close();
        }

        private void PokazWypozyczenia()
        {
            List<Wypozyczenie> dostepneKsiazki = kontobiblioteczne.listaWypozyczenKonta.Where(w => w.WysokoscKary()==0).ToList();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek do zwrotu w tej chwili. Wypożycz książkę, lub ureguluj należności, jeżeli książka jest po terminie.");
            }
            else
            {
                ComboBoxWypozyczenia.ItemsSource = dostepneKsiazki;
            }
        }

        private void WydluzTermin(object sender, SelectionChangedEventArgs e)
        {
            if(sender is ComboBox comboBox && comboBox.SelectedItem is Wypozyczenie w)
            {
                w.PrzedluzTerminWypozyczenia();
                MessageBox.Show("Przedluzono termin wypożyczenia");
                KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
                kontoOkno.Show();
                this.Close();
            }

        }
    }
}
