﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BibliotekaUI
{

    public partial class WypozyczKsiazke : Window
    {
        private KontoBiblioteczne kontobiblioteczne;
        private Filia filiaBiblioteka;
        public WypozyczKsiazke(KontoBiblioteczne konto, Filia filia)
        {
            InitializeComponent();
            kontobiblioteczne = konto;
            filiaBiblioteka = filia;

            PokazDostepneKsiazki();
            PokazDostepneGatunki();
            PokazDostepnychAutorow();

        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
            kontoOkno.Show();
            this.Close();
        }

        private void PokazDostepneGatunki()
        {
            List<Ksiazka> dostepneKsiazki = filiaBiblioteka.WyszukajKsiazkiDostepne();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek w tej chwili!");
            }
            else
            {
                var unikalneGatunki = dostepneKsiazki.Select(k => k.typKsiazki.ToString()).Distinct().OrderBy(g => g).ToList();  
                ComboBoxGatunek.Items.Clear();
                ComboBoxGatunek.ItemsSource = unikalneGatunki;
            }
        }

        private void PokazDostepnychAutorow()
        {
            List<Ksiazka> dostepneKsiazki = filiaBiblioteka.WyszukajKsiazkiDostepne();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek w tej chwili!");
            }
            else
            {
                var unikalniAutorzy = dostepneKsiazki.Select(k => k.Autor).Distinct().OrderBy(g => g).ToList(); 
                ComboBoxAutorzy.Items.Clear();
                ComboBoxAutorzy.ItemsSource = unikalniAutorzy;
            }
        }

        private void PokazDostepneKsiazki(string gatunek = " ", string autor = " ")
        {
            List<Ksiazka> dostepneKsiazki = filiaBiblioteka.WyszukajKsiazkiDostepne();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek w tej chwili!");
            }
            else
            {

                var filteredBooks = dostepneKsiazki.AsEnumerable();
                if (gatunek != " ")
                {
                    filteredBooks = filteredBooks.Where(k => k.typKsiazki.ToString() == gatunek);
                }
                if (autor != " ")
                {
                    filteredBooks = filteredBooks.Where(k => k.Autor == autor);
                }
                ListBoxKsiazki.ItemsSource = filteredBooks.ToList();
            }
        }


        private void Gatunek(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is string gatunek)
            {
                PokazDostepneKsiazki(gatunek, " ");
            }
        }

        private void Autor(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is string autor)
            {
                PokazDostepneKsiazki(" ", autor);
            }
        }

        private void WybranaKsiazka(object sender, SelectionChangedEventArgs e)
        {
            if (kontobiblioteczne.ileWypozyczonych < kontobiblioteczne.limitWypozyczen)
            {
                if (sender is ListBox listBox && listBox.SelectedItem is Ksiazka ksiazka)
                {
                    Wypozyczenie w = new(kontobiblioteczne, ksiazka);
                    MessageBox.Show($"Wypożyczono książkę: {ksiazka.Tytul} {ksiazka.Autor}");

                    KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
                    kontoOkno.Show();
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Osiągnięto limit wypożyczeń. Zwróć książki, aby wypożyczyć nowe.");
            }
        }








    }




}



