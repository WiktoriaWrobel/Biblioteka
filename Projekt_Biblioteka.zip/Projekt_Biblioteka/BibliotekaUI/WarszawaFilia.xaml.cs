﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BibliotekaUI
{

    public partial class WarszawaFilia : Window
    {
        public string CurrentDateTime { get; private set; }
        private Filia filiaBiblioteka; 

        public WarszawaFilia()
        {
            InitializeComponent();
            Data();

            string katalogProjektu = System.IO.Path.GetFullPath(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\.."));
            Directory.SetCurrentDirectory(katalogProjektu);
            string sciezkaWzgledna = $@"Filie\Warszawa";
            string sciezkaAbsolutna = System.IO.Path.Combine(Directory.GetCurrentDirectory(), sciezkaWzgledna);
            filiaBiblioteka = Filia.OdczytDCXml(sciezkaAbsolutna);
            if (filiaBiblioteka == null)
            {
                MessageBox.Show("Nie udało się wczytać danych filii Warszawa. Sprawdź plik źródłowy.");
                throw new Exception("Błąd wczytania filii.");
            }

        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            MainWindow mainwindow = new MainWindow();
            mainwindow.Show();
            this.Close();
        }

        public void Data()
        {
            CurrentDateTime = DateTime.Now.ToString("yyyy-MM-dd");
            this.DataContext = this;
        }

        private void Uzytkownik(object sender, RoutedEventArgs e)
        {
            string login = NazwaUzytkownika.Text.Trim();

            var konto = filiaBiblioteka.WyszukajKontoWedlugNazwyUzytkownika(login);
            if (!konto.Any())
            {
                MessageBox.Show("Nie znaleziono użytkownika.");
            }
            else
            {
                KontoUzytkownika kontoOkno = new KontoUzytkownika(konto.First(), filiaBiblioteka);
                kontoOkno.Show();

                this.Close();

            }

        }

        private void RejestracjaUzytkownika(object sender, RoutedEventArgs e)
        {
            ZarejestrujSie zarejestrujSie = new(filiaBiblioteka);
            zarejestrujSie.Show();
            this.Close();
        }

        private void NazwaUzytkownika_GotFocus(object sender, RoutedEventArgs e)
        {
            if (NazwaUzytkownika.Text == "Nazwa użytkownika")
            {
                NazwaUzytkownika.Text = string.Empty;
            }
        }

        private void NazwaUzytkownika_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NazwaUzytkownika.Text))
            {
                NazwaUzytkownika.Text = "Nazwa użytkownika";
            }
        }

        private void AktualneZasoby(object sender, RoutedEventArgs e)
        {
            AktualneZasoby aktualneZasoby = new(filiaBiblioteka);
            aktualneZasoby.Show();
        }
    }


}

