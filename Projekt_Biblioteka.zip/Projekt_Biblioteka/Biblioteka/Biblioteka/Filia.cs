﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Biblioteka
{
    #region zadeklarowanie wyjatkow
    class NieznalezionoKsiazkiException : Exception
    {
        public NieznalezionoKsiazkiException() : base() { }
        public NieznalezionoKsiazkiException(string message) : base(message) { }
    }
    #endregion

    [DataContract]
    [KnownType(typeof(Ksiazka))]
    [KnownType(typeof(KontoBiblioteczne))]
    [KnownType(typeof(KontoBibliotecznePremium))]
    [KnownType(typeof(KontoBibliotecznePodstawowe))]
    [KnownType(typeof(Wypozyczenie))]
    public class Filia : IFilia, ICloneable
    {
        [DataMember]
        string nazwaFilii;
        [DataMember]
        List<Ksiazka> listaKsiazek = new();
        [DataMember]
        List<KontoBiblioteczne> listaKont = new();

        public List<Ksiazka> ListaKsiazek { get => listaKsiazek; set => listaKsiazek = value; }
        public List<KontoBiblioteczne> ListaKont { get => listaKont; set => listaKont = value; }
        public string NazwaFilii { get => nazwaFilii; set => nazwaFilii = value; }

        public Filia(string nazwaFilii)
        {
            this.NazwaFilii = nazwaFilii;
            ListaKsiazek = new List<Ksiazka>();
            ListaKont = new List<KontoBiblioteczne>();

            // komunikaty dodawania nowej książku lub konta
            DodanoKsiazke += ksiazka => Console.WriteLine($"Dodano książkę: \"{ksiazka.Tytul}\"");
            DodanoKonto += konto => Console.WriteLine($"Dodano konto: {konto.Nazwauzytkownika}");
        }

        #region zaimplementowany interfejs

        public void DodajKsiazke(Ksiazka k)
        {
            ListaKsiazek.Add(k);
            DodanoKsiazke?.Invoke(k); // Wywołanie zdarzenia, jeśli zostało zarejestrowane
            //PowiadomONowejKsiazce();
        }

        public int Ileksiazek()
        {
            return ListaKsiazek.Count();
        }

        public int PoliczKsiazkiAutor(string autor)
        {
            return ListaKsiazek.Where(k => k.Autor == autor).Count();
        }

        public int PoliczKsiazkiTemat(EnumTypKsiazki typKsiazki)
        {
            return ListaKsiazek.Where(k => k.typKsiazki == typKsiazki).Count();
        }

        public void UsunKsiazkePoNumerze(string kodKsiazki)
        {
            Ksiazka ksiazkaDoUsuniecia = ListaKsiazek.FirstOrDefault(k => k.kodKsiazki == kodKsiazki);
            if(ksiazkaDoUsuniecia is null)
            {
                Console.WriteLine($"Ksiazka o kodzie {kodKsiazki} nie istnieje w naszej filii");
            }
            else
            {
                ListaKsiazek.Remove(ksiazkaDoUsuniecia);
                Console.WriteLine("Usunieto poprawnie");
            }
        }

        public List<Ksiazka> WyszkukajKsiazkiTyp(EnumTypKsiazki typKsiazki)
        {
            return ListaKsiazek.Where(k => k.typKsiazki == typKsiazki).ToList();
            
        }

        public List<Ksiazka> WyszukajKsiazkiAutora(string autor)
        {
            return ListaKsiazek.Where(k => k.Autor == autor).ToList();
        }
        

        

        public void UtworzKonto(KontoBiblioteczne kb)
        {
           ListaKont.Add(kb);
           DodanoKonto?.Invoke(kb); // Wywołanie zdarzenia, jeśli zostało zarejestrowane
           //PowiadomONowymKoncie();
        }

        public void UsunKonto(string nazwauzytkownika)
        {
            KontoBiblioteczne kontoDoUsuniecia = ListaKont.FirstOrDefault(k => k.Nazwauzytkownika == nazwauzytkownika);
            if(kontoDoUsuniecia is null)
            {
                Console.WriteLine($"Nie znaleziono konta o nazwie {kontoDoUsuniecia}");
            }
            else
            {
                ListaKont.Remove(kontoDoUsuniecia);
                Console.WriteLine("Konto usuniete poprawnie z systemu");
            }
        }
        #endregion
        public override string ToString()
        {
            StringBuilder sb = new();
            sb.AppendLine($"Filia {NazwaFilii} ({Ileksiazek()}):");
            foreach (Ksiazka k in ListaKsiazek)
            {
                sb.AppendLine(k.ToString());
            }
            return sb.ToString();
        }

        #region sortowanie 
        public void SortujKsiazkiPoTytule() 
        { 
            Ksiazka.RodzajSortowania = Sortowanie.Tytul; 
            ListaKsiazek.Sort(); 
        }
        public void SortujKsiazkiPoAutorze() 
        { 
            Ksiazka.RodzajSortowania = Sortowanie.Autor; 
            ListaKsiazek.Sort(); 
        }
        public void SrotujKsiazkiPoAutorzeITytule() 
        { 
            Ksiazka.RodzajSortowania = Sortowanie.AutorTytul; 
            ListaKsiazek.Sort();
        }
        #endregion

        public object Clone()
        {
            Filia? f = MemberwiseClone() as Filia; 
            if (f is not null)
            {
                f.ListaKont = new();
                ListaKont.ForEach(k => f.ListaKont.Add(k.Clone() as KontoBiblioteczne)); 
                f.ListaKsiazek = new();
                ListaKsiazek.ForEach(ks => f.ListaKsiazek.Add(ks.Clone() as Ksiazka)); 
            }
            return f;
        }

        #region serializacja i deserializacja
        //serializacja i deserializacja 
        public void ZapisDCXml(string nazwa)
        {
            DataContractSerializer dsc = new(typeof(Filia));
            using XmlTextWriter writer = new (nazwa, Encoding.UTF8)
            { Formatting = Formatting.Indented};
            dsc.WriteObject(writer, this);
        }

        public static Filia? OdczytDCXml(string nazwa)
        {
            if (!File.Exists(nazwa)) { return null; }
            DataContractSerializer dsc = new(typeof(Filia));
            using XmlTextReader reader = new(nazwa);
            return dsc.ReadObject(reader) as Filia;
        }

        #endregion

        public void UsunDuplikatyKont()
        {
            List<KontoBiblioteczne> unikalneKonta = new List<KontoBiblioteczne>();
            
            foreach (KontoBiblioteczne konto in ListaKont)
            {
                if (!unikalneKonta.Any(k => k.Equals(konto)))
                {
                    unikalneKonta.Add(konto);
                }
            }

            ListaKont = unikalneKonta;
        }

        public bool CzyKsiazkaIstnieje(Ksiazka ksiazka)
        {
            return ListaKsiazek.Any(k => k.Equals(ksiazka));
        }

        public bool CzyKontoIstnieje(KontoBiblioteczne kontoBiblioteczne)
        {
            return ListaKont.Any(kb => kb.Equals(kontoBiblioteczne));
        }

        // Delegat definiujący kryterium filtracji kont
        public delegate bool KryteriumFiltracjiKont(KontoBiblioteczne konto);

        public List<KontoBiblioteczne> FiltrujKonta(KryteriumFiltracjiKont kryterium)
        {
            return ListaKont.Where(kryterium.Invoke).ToList();
        }

        //wyszukiwanie konta po peselu
        public List<KontoBiblioteczne> WyszukajKontoWedlugPeselu(string pesel)
        {
            return FiltrujKonta(konto => konto.Pesel == pesel);
        }

        //wyszukiwanie konta według nazwy użytkownika
        public List<KontoBiblioteczne> WyszukajKontoWedlugNazwyUzytkownika(string nazwauzytkownika)
        {
            return FiltrujKonta(konto => konto.Nazwauzytkownika == nazwauzytkownika);
        }

        //konta z maksymalnym limitem wypożyczeń 
        public List<KontoBiblioteczne> MaksymalnyLimit()
        {
            return FiltrujKonta(k => k.ileWypozyczonych == k.limitWypozyczen);
        }

        //konta bez wypożyczeń
        public List<KontoBiblioteczne> KontaBezWypozyczen()
        {
            return FiltrujKonta(k => k.ileWypozyczonych == 0);
        }

        // konta premium 
        public List<KontoBiblioteczne> PobierzKontaPremium()
        {
            return FiltrujKonta(k => k is KontoBibliotecznePremium);
        }

        //konta podstawowe 
        public List<KontoBiblioteczne> PobierzKontaPodstawowe()
        {
            return FiltrujKonta(k => k is KontoBibliotecznePodstawowe);
        }

        // Delegat definiujący kryterium wyszukiwania książek
        public delegate bool KryteriumWyszukiwaniaKsiazek(Ksiazka ksiazka);

        public List<Ksiazka> WyszukajKsiazki(KryteriumWyszukiwaniaKsiazek kryterium)
        {
            return ListaKsiazek.Where(kryterium.Invoke).ToList();
        }

        //książki zawierające podane słowo w tytule 
        public List<Ksiazka> KsiazkiSlowoWTytule(string fraza)
        {
            return WyszukajKsiazki(k => k.Tytul.Contains(fraza, StringComparison.OrdinalIgnoreCase));
        }

        //wyszukiwanie ksiazek na podstawie wydawnictwa 
        public List<Ksiazka> WyszukajWedlugWydawnictwa(EnumWydawnictwo wydawnictwo)
        {
            return WyszukajKsiazki(k => k.Wydawnictwo == wydawnictwo);
        }

        //wyszukiwanie wypożyczonych ksiązek
        public List<Ksiazka> WyszukajKsiazkiWypozyczone()
        {
            return WyszukajKsiazki(k => k.czyWypozyczona);
        }

        //wyszukiwanie dostępnych ksiązek 
        public List<Ksiazka> WyszukajKsiazkiDostepne()
        {
            return WyszukajKsiazki(k => !k.czyWypozyczona);
        }

        //wyszukiwanie ksiazek o podanym zakresie numerów ksiązek 
        public List<Ksiazka> WyszukajKsiazkiZZakresuNumerow(int minNumer, int maxNumer)
        {
            return WyszukajKsiazki(k => k.NumerKsiazki >= minNumer && k.NumerKsiazki <= maxNumer);
        }

        // Delegaty zdarzeń
        public delegate void KsiazkaZdarzenie(Ksiazka ksiazka);
        public delegate void KontoZdarzenie(KontoBiblioteczne konto);

        // Zdarzenia
        public event KsiazkaZdarzenie DodanoKsiazke;
        public event KontoZdarzenie DodanoKonto;


        // komunikat dodawania nowej ksiazki 

        //public void PowiadomONowejKsiazce()
        //{
           // DodanoKsiazke += ksiazka => Console.WriteLine($"Dodano książkę: \"{ksiazka.Tytul}\"");
        //}

        // komunikat dodawania nowego konta 
       //public void PowiadomONowymKoncie()
        //{
          //  DodanoKonto += konto => Console.WriteLine($"Dodano konto: {konto.Nazwauzytkownika}");
        //}


    }
}
