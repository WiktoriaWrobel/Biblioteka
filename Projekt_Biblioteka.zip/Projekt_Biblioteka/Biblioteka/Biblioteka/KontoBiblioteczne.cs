﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Biblioteka
{
    #region zadeklarowanie wyjatkow
    public class WrongPeselException : Exception
    {
        public WrongPeselException() : base() { }
        public WrongPeselException(string msg) : base(msg) { }
    }
    public class ZaKtotkiFormatException : Exception
    {
        public ZaKtotkiFormatException() : base() { }
        public ZaKtotkiFormatException(string msg) : base(msg) { }
    }
    public class ZaMlodyException : Exception
    {
        public ZaMlodyException() : base() { }
        public ZaMlodyException(string msg) : base(msg) { }
    }
    #endregion

    [DataContract(IsReference = true)]
    [KnownType(typeof(KontoBibliotecznePremium))]
    [KnownType(typeof(KontoBibliotecznePodstawowe))]
    public abstract class KontoBiblioteczne : ICloneable, IEquatable<KontoBiblioteczne>
    {
        [DataMember]
        string imie;
        [DataMember]
        string nazwisko;
        [DataMember]
        private string pesel;
        [DataMember]
        string nazwauzytkownika;
        [DataMember]
        private DateTime dataUrodzenia;
        [DataMember]
        static int biezacyNumerKonta;
        [DataMember]
        public int limitWypozyczen;
        [DataMember]
        int aktuanyNumerKonta;
        public abstract decimal StawkaKary { get; }
        [DataMember]
        public int ileWypozyczonych;
        [DataMember]
        public List<Wypozyczenie> listaWypozyczenKonta = new();


        #region sprawdzanie poprawnosci -> korzystanie z właściwości
        public string Imie
        {
            get => imie;
            set
            {
                if (!Regex.IsMatch(value, @"^[A-Z]"))
                {
                    throw new DuzaLiteraException("Imie musi byc napisane z duzej litery");
                }
                imie = value;
            }
        }
        public string Nazwisko
        {
            get => nazwisko;
            set
            {
                if (!Regex.IsMatch(value, @"^[A-Z]"))
                {
                    throw new DuzaLiteraException("Nazwisko musi byc napisane z duzej litery");
                }
                nazwisko = value;
            }
        }
        public string Pesel
        {
            get => pesel;
            set
            {
                if (!Regex.IsMatch(value, @"\d{11}$"))
                {
                    throw new WrongPeselException("Pesel musi miec 11 znakow");
                }
                else
                {
                    pesel = value;
                }

            }
        }
        public string Nazwauzytkownika
        {
            get => nazwauzytkownika;
            set
            {
                if (value.Length < 3)
                {
                    throw new ZaKtotkiFormatException();
                }
                nazwauzytkownika = value;
            }
        }

        public int Wiek(DateTime dataUrodzenia)
        {
            int wiek = DateTime.Now.Year - dataUrodzenia.Year;
            if (dataUrodzenia > DateTime.Now) { wiek = wiek - 1; }
            return wiek;
        }
        public DateTime DataUrodzenia
        {
            get => dataUrodzenia;
            set
            {
                if (Wiek(dataUrodzenia) < 18)
                {
                    throw new ZaMlodyException();
                }
                dataUrodzenia = value;
            }
        }
        #endregion

        static KontoBiblioteczne()
        {
            biezacyNumerKonta = 1000;
        }
        public KontoBiblioteczne(string imie, string nazwisko, string pesel, string nazwauzytkownika, string dataUrodzenia)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Pesel = pesel;
            Nazwauzytkownika = nazwauzytkownika;
            DateTime.TryParseExact(dataUrodzenia, new[] { "yyyy-MM-dd", "dd-MM-yyyy" }, null, DateTimeStyles.None, out DateTime sparsowanaDataUrodzenia);
            DataUrodzenia = sparsowanaDataUrodzenia;
            aktuanyNumerKonta = biezacyNumerKonta;
            biezacyNumerKonta++;
            ileWypozyczonych = 0;
            //limitWypozyczen = 3;
        }

        public void PokazWypozyczenia()
        {
            if (listaWypozyczenKonta.Count == 0)
            {
                Console.WriteLine("Brak wypożyczeń na tym koncie.");
            }
            else
            {
                Console.WriteLine($"Wypożyczenia dla konta użytkownika: {Nazwauzytkownika}");
                foreach (var wypozyczenie in listaWypozyczenKonta)
                {
                    Console.WriteLine($"\"{wypozyczenie.ksiazka.Tytul}\" ({wypozyczenie.ksiazka.Autor}): {wypozyczenie.dataWypozyczenia:yyyy-MM-dd} - {wypozyczenie.dataZwrotu:yyyy-MM-dd}");
                    if(wypozyczenie.WysokoscKary() > 0)
                    {
                        Console.WriteLine($"Ksiazka {wypozyczenie.IlePoTerminie()} dni po terminie, wysokosc kary: {wypozyczenie.WysokoscKary():c}");
                    }
                }
            }
        }
        public override string ToString()
        {
            return $"{Nazwauzytkownika}\nDane:\n nr konta: {biezacyNumerKonta}\n {imie} {nazwisko} {Wiek(dataUrodzenia)} lat";
        }

        public object Clone()
        {
            return MemberwiseClone();
        }

        public bool Equals(KontoBiblioteczne? other)
        {
            if (other == null) return false;
            return Nazwauzytkownika == other.Nazwauzytkownika || Pesel == other.Pesel;
        }

        public bool CzyWypozyczenieIstnieje(Wypozyczenie wypozyczenie)
        {
            return listaWypozyczenKonta.Any(w => w.Equals(wypozyczenie));
        }
    }
}
