﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    internal interface IFilia
    {
        void DodajKsiazke(Ksiazka k);
        void UsunKsiazkePoNumerze(string kodKsiazki);

        List<Ksiazka> WyszukajKsiazkiAutora(string autor);
        List<Ksiazka> WyszkukajKsiazkiTyp(EnumTypKsiazki typKsiazki);
        int Ileksiazek();
        int PoliczKsiazkiTemat(EnumTypKsiazki typKsiazki);
        int PoliczKsiazkiAutor(string autor);
        void UtworzKonto(KontoBiblioteczne kb);
        void UsunKonto(string nazwauzytkownika);

    }
}
