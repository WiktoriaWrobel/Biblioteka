﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class PoTerminieException : Exception
    {
        public PoTerminieException(): base() {}
        public PoTerminieException(string message) : base(message) { }

    }
    public class BladWypozyczenia : Exception
    {
        public BladWypozyczenia() : base() { }
        public BladWypozyczenia(string message) : base(message) { }

    }

    [DataContract(IsReference = true)]
    public class Wypozyczenie : IWypozyczenie, IEquatable<Wypozyczenie>
    {
        [DataMember]
        public DateTime dataWypozyczenia;
        [DataMember]
        public DateTime dataZwrotu;
        [DataMember]
        bool czyPoDacieZwrotu;
        [DataMember]
        static int numerWypozyczenia;
        [DataMember]
        int aktualnyNumerWypozyczenia;
        [DataMember]
        private KontoBiblioteczne konto;
        [DataMember]
        public Ksiazka ksiazka;
        [DataMember]
        decimal wysokoscKary;

        //static Dictionary<int, KontoBiblioteczne> slownikKontZWypozyczeniami = new(); 
        //robie to by potem móc wyciągnąć z numeru wypozyczenia wysokosc kary, która jest zależna od typu konta
        //dlatego ten krok jest niezbędny
        
        static Wypozyczenie()
        {
            numerWypozyczenia = 1;
        }

        public Wypozyczenie(KontoBiblioteczne kb, Ksiazka k)
        {
            if(kb.ileWypozyczonych >= kb.limitWypozyczen)
            {
                throw new BladWypozyczenia("Limit wypozyczonych ksiazek dla konta zostal wyczerpany");
            }
            if(k.czyWypozyczona == true)
            {
                throw new BladWypozyczenia("Ksiazka wypozyczona");
            }
            k.czyWypozyczona = true;
            dataWypozyczenia = DateTime.Now;
            dataZwrotu = DateTime.Now.AddMonths(1);
            czyPoDacieZwrotu = false;
            aktualnyNumerWypozyczenia = numerWypozyczenia;
            numerWypozyczenia += 1;
            kb.ileWypozyczonych++;
            konto = kb;
            ksiazka = k;
            wysokoscKary = 0;
            konto.listaWypozyczenKonta.Add(this);

        }
        public Wypozyczenie(KontoBiblioteczne kb, Ksiazka k, string dataWypozyczenia) : this(kb, k)
        {
            DateTime.TryParseExact(dataWypozyczenia, new[] { "yyyy-MM-dd", "dd-MM-yyyy" }, null, DateTimeStyles.None, out DateTime sparsowanaDataWypozyczenia);
            this.dataWypozyczenia = sparsowanaDataWypozyczenia;
            dataZwrotu = sparsowanaDataWypozyczenia.AddMonths(1);
            czyPoDacieZwrotu = false;
            if (dataZwrotu < DateTime.Now)
            {
                czyPoDacieZwrotu = true;
            }


        }

        public int IlePoTerminie()
        {
            int ilepoterminie = 0;
            if(dataZwrotu < DateTime.Now)
            {
                ilepoterminie = (DateTime.Now - dataZwrotu).Days;
            }
            return ilepoterminie;
        }

        public void PrzedluzTerminWypozyczenia()
        {
            if(czyPoDacieZwrotu == false)
            {
                dataZwrotu = dataZwrotu.AddMonths(1);
            }
            else
            {
                throw new PoTerminieException($"Ksiazka {IlePoTerminie()} - nie mozna przedluzyc");
            }
        }
        public decimal WysokoscKary()
        {
            int ileDniPoTerminie = IlePoTerminie();

            return (decimal)ileDniPoTerminie * konto.StawkaKary;
        }

        public void UregulujNaleznosci()
        {
            decimal ile = WysokoscKary();
            wysokoscKary = 0;
            Console.WriteLine($"Pomyslnie oplcacono naleznosc za ksiazke \"{ksiazka.Tytul}\"");
        }

        public void ZwrocKsiazke()
        {
            if (wysokoscKary != 0)
            {
                throw new PoTerminieException($"Nie uregulowano naleznosci w wysokosci: {wysokoscKary}");
            }
            ksiazka.czyWypozyczona = false;
            konto.ileWypozyczonych -= 1;
            Console.WriteLine($"Poprawnie oddano ksiazke \"{ksiazka.Tytul}\". Twoja aktualna liczba wypozyczen to: {konto.ileWypozyczonych}");

        }

        public override string ToString()
        {
            if(czyPoDacieZwrotu == false) //jakoś źle mi to działa
            {
                return $"{konto} : wypozyczona ksiazka \"{ksiazka.Tytul}\" data zwrotu: {dataZwrotu:yyyy-MM-dd}";
            }
            return $"{konto} : wypozyczona ksiazka \"{ksiazka.Tytul}\"\nKsiazka po terminie {IlePoTerminie()} dni do zaplaty: {WysokoscKary():c}";
        }

        public bool Equals(Wypozyczenie? other)
        {
            if (other == null) return false;
            return ksiazka.Equals(other.ksiazka) && konto.Equals(other.konto);
        }
    }
}
