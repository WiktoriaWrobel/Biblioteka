﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class GatunekException : Exception
    {
        public GatunekException() : base() { }
        public GatunekException(string message) : base(message) { }
    }
    internal class Propozycja
    { 
        EnumTypKsiazki ulubionyGatunek;
        List<Filia> listaFilii;
        KontoBiblioteczne konto;


        public Propozycja (string ulubionyGatunek, KontoBiblioteczne k, List<Filia> filie)
        {
            if(!Enum.TryParse(ulubionyGatunek, true, out EnumTypKsiazki gatunek))
            {
                throw new GatunekException("Brak podanego gatunku w bibliotece.");
            }
            this.ulubionyGatunek = gatunek;

            this.konto = k;
            this.listaFilii = filie;
        }


        public void Proponuj()
        {
            // Pobranie nazwy użytkownika z przekazanego konta
            string nazwauzytkownika = konto.Nazwauzytkownika;

            // Sprawdzenie, czy konto biblioteczne należy do którejś z filii
            List<Filia> filieZKonto = listaFilii.Where(f => f.ListaKont.Any(k => k.Nazwauzytkownika == nazwauzytkownika)).ToList();
            if (!filieZKonto.Any())
            {
                Console.WriteLine($"Użytkownik {nazwauzytkownika} nie ma konta w żadnej filii.");
                return;
            }

            // Sprawdzenie, czy w każdej z filii są książki z tego gatunku
            foreach (Filia filia in filieZKonto)
            {
                List<Ksiazka> ksiazkiZGatunku = filia.ListaKsiazek.Where(k => k.typKsiazki == ulubionyGatunek).ToList();
                if (!ksiazkiZGatunku.Any())
                {
                    Console.WriteLine($"W filii {filia.NazwaFilii} nie ma książek z gatunku {ulubionyGatunek}.");
                    continue;
                }

                // Losowanie i wypisanie do 3 książek z tego gatunku (lub mniej jeśli nie ma 3)
                int iloscDoWyswietlenia = Math.Min(3, ksiazkiZGatunku.Count);
                var wylosowaneKsiazki = ksiazkiZGatunku.OrderBy(k => Guid.NewGuid()).Take(iloscDoWyswietlenia);

                Console.WriteLine($"Polecane książki z gatunku {ulubionyGatunek} w filii {filia.NazwaFilii}:");

                foreach (Ksiazka ksiazka in wylosowaneKsiazki)
                {
                Console.WriteLine($"- \"{ksiazka.Tytul}\", autor: {ksiazka.Autor}");
                }
            }
        }

    }
}
