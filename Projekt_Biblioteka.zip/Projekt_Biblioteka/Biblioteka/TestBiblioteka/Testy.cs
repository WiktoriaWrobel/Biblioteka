using Biblioteka;

namespace TestBiblioteka
{
    namespace BibliotekaTests
    {
        [TestClass]
        public class FiliaTests
        {
            [TestMethod]
            public void TestListy()
            {
                Filia f = new("Filia Testowa");
                Assert.IsNotNull(f.ListaKont);
                Assert.IsNotNull(f.ListaKsiazek);
            }

            [TestMethod]
            public void TestDodajKsiazkeDoListy()
            {
                Filia filia = new("Filia Testowa");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor");

                filia.DodajKsiazke(ksiazka);

                Assert.AreEqual(1, filia.ListaKsiazek.Count);
                Assert.IsTrue(filia.ListaKsiazek.Contains(ksiazka));
            }

            [TestMethod]
            public void TestUsunKsiazkePoNumerze()
            {
                Filia filia = new("Filia Testowa");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor");
                filia.DodajKsiazke(ksiazka);

                filia.UsunKsiazkePoNumerze(ksiazka.kodKsiazki);

                Assert.AreEqual(0, filia.ListaKsiazek.Count);
            }

            [TestMethod]
            public void TestIleksiazek()
            {
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor"));

                int liczbaKsiazek = filia.Ileksiazek();

                Assert.AreEqual(1, liczbaKsiazek);
            }

            [TestMethod]
            public void TestPoliczKsiazkiAutor()
            {
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor1"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Inny Horror", "Autor1"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Romans, EnumWydawnictwo.Znak, "Romans", "Autor2"));

                int liczbaKsiazekAutora = filia.PoliczKsiazkiAutor("Autor1");

                Assert.AreEqual(2, liczbaKsiazekAutora);
            }

            [TestMethod]
            public void TestPoliczKsiazkiTemat()
            {
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror1", "Autor"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Znak, "Horror2", "Autor"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Romans, EnumWydawnictwo.Znak, "Romans", "Autor"));

                int liczbaKsiazekTematu = filia.PoliczKsiazkiTemat(EnumTypKsiazki.Horror);

                Assert.AreEqual(2, liczbaKsiazekTematu);
            }

            [TestMethod]
            public void TestWyszkukajKsiazkiTyp()
            {
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Romans, EnumWydawnictwo.Znak, "Romans", "Inny Autor"));

                List<Ksiazka> ksiazkiHorror = filia.WyszkukajKsiazkiTyp(EnumTypKsiazki.Horror);

                Assert.AreEqual(1, ksiazkiHorror.Count);
                Assert.AreEqual("Horror", ksiazkiHorror[0].Tytul);
            }

            [TestMethod]
            public void TestWyszukajKsiazkiAutora()
            {
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Znak, "Thriller", "Inny Autor"));

                List<Ksiazka> result = filia.WyszukajKsiazkiAutora("Autor");

                Assert.AreEqual(1, result.Count);
                Assert.AreEqual("Autor", result[0].Autor);
            }

            [TestMethod]
            public void TestSortujKsiazkiPoTytule()
            { 
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "B", "Autor"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "A", "Autor"));

                filia.SortujKsiazkiPoTytule();

                Assert.AreEqual("A", filia.ListaKsiazek[0].Tytul);
            }

            [TestMethod]
            public void TestUtworzKonto()
            {
                Filia filia = new("Filia Testowa");
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "1990-01-01");

                filia.UtworzKonto(konto);

                Assert.AreEqual(1, filia.ListaKont.Count);
                Assert.IsTrue(filia.ListaKont.Contains(konto));
            }

            [TestMethod]
            public void TestUsunKonto()
            {
                Filia filia = new("Filia Testowa");
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "1990-01-01");
                filia.UtworzKonto(konto);

                filia.UsunKonto("jan123");

                Assert.AreEqual(0, filia.ListaKont.Count);
            }

            [TestMethod]
            public void TestWyszukajKsiazkiDostepne()
            {
                Filia filia = new("Filia Testowa");
                Ksiazka ksiazka1 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Ksiazka 1", "Autor");
                Ksiazka ksiazka2 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Ksiazka 2", "Autor");
                ksiazka2.czyWypozyczona = true;
                filia.DodajKsiazke(ksiazka1);
                filia.DodajKsiazke(ksiazka2);

                List<Ksiazka> result = filia.WyszukajKsiazkiDostepne();

                Assert.AreEqual(1, result.Count);
                Assert.AreEqual("Ksiazka 1", result[0].Tytul);
            }

            [TestMethod]
            public void TestWyszukajKontoWedlugPeselu()
            {
                Filia filia = new("Filia Testowa");
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "1990-01-01");
                filia.UtworzKonto(konto);

                List<KontoBiblioteczne> wynik = filia.WyszukajKontoWedlugPeselu("12345678901");

                Assert.AreEqual(1, wynik.Count);
                Assert.AreEqual(konto, wynik[0]);
            }

            [TestMethod]
            public void TestWyszukajKontoWedlugNazwyUzytkownika()
            {
                Filia filia = new("Filia Testowa");
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "1990-01-01");
                filia.UtworzKonto(konto);

                List<KontoBiblioteczne> wynik = filia.WyszukajKontoWedlugNazwyUzytkownika("jan123");

                Assert.AreEqual(1, wynik.Count);
                Assert.AreEqual(konto, wynik[0]);
            }

            [TestMethod]
            public void TestKontaZPelnaLiczbaWypozyczen()
            {
                Filia filia = new("Filia Testowa");
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "1990-01-01");
                konto.ileWypozyczonych = konto.limitWypozyczen;
                filia.UtworzKonto(konto);

                List<KontoBiblioteczne> result = filia.MaksymalnyLimit();

                Assert.AreEqual(1, result.Count);
                Assert.AreEqual(konto, result[0]);
            }

            [TestMethod]
            public void TestKsiazkiSlowoWTytule()
            {
                Filia filia = new("Filia testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror Historia", "Autor 1"));
                filia.DodajKsiazke(new(EnumTypKsiazki.Romans, EnumWydawnictwo.Znak, "Romans", "Autor 2"));

                var result = filia.KsiazkiSlowoWTytule("Historia");

                Assert.AreEqual(1, result.Count);
                Assert.AreEqual("Horror Historia", result[0].Tytul);
            }

            [TestMethod]
            public void TestClone()
            {
                Filia filia = new("Filia Testowa");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor");
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "1990-01-01");
                filia.DodajKsiazke(ksiazka);
                filia.UtworzKonto(konto);

                Filia? kopia = filia.Clone() as Filia;

                Assert.IsNotNull(kopia);
                Assert.AreNotSame(filia, kopia);
                Assert.AreEqual(filia.NazwaFilii, kopia.NazwaFilii);
                Assert.AreEqual(filia.ListaKsiazek.Count, kopia.ListaKsiazek.Count);
                Assert.AreEqual(filia.ListaKont.Count, kopia.ListaKont.Count);
                Assert.AreNotSame(filia.ListaKsiazek[0], kopia.ListaKsiazek[0]); // Sprawdza g��bok� kopi�
                Assert.AreNotSame(filia.ListaKont[0], kopia.ListaKont[0]);       // Sprawdza g��bok� kopi�
            }

            [TestMethod]
            public void TestZapisDCXml()
            {
                string nazwaPliku = "test_filia.xml";
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor"));

                filia.ZapisDCXml(nazwaPliku);

                Assert.IsTrue(File.Exists(nazwaPliku));

                File.Delete(nazwaPliku);
            }

            [TestMethod]
            public void TestOdczytDCXml()
            {
                // Arrange
                string nazwaPliku = "test_filia.xml";
                Filia filia = new("Filia Testowa");
                filia.DodajKsiazke(new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Horror", "Autor"));
                filia.ZapisDCXml(nazwaPliku);

                Filia? odczytanaFilia = Filia.OdczytDCXml(nazwaPliku);

                Assert.IsNotNull(odczytanaFilia);
                Assert.AreEqual(filia.NazwaFilii, odczytanaFilia.NazwaFilii);
                Assert.AreEqual(filia.ListaKsiazek.Count, odczytanaFilia.ListaKsiazek.Count);
                Assert.AreEqual(filia.ListaKsiazek[0].Tytul, odczytanaFilia.ListaKsiazek[0].Tytul);

                File.Delete(nazwaPliku);
            }

        }

        [TestClass]
        public class KontoBiblioteczneTests
        {
            [TestMethod]
            public void TestTworzenieKonta()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "uzytkownik", "2000-01-01");

                Assert.AreEqual("Jan", konto.Imie);
                Assert.AreEqual("Kowalski", konto.Nazwisko);
                Assert.AreEqual("12345678901", konto.Pesel);
                Assert.AreEqual("uzytkownik", konto.Nazwauzytkownika);
            }

            [TestMethod]
            public void TestNieprawidlowyPesel()
            {
                Assert.ThrowsException<WrongPeselException>(() =>
                {
                    KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "123", "jan123", "1990-01-01");
                });
            }

            [TestMethod]
            public void TestNiepoprawneImie()
            {
                Assert.ThrowsException<DuzaLiteraException>(() =>
                {
                    KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                });
            }

            [TestMethod]
            public void TestNiepoprawneNazwisko()
            {
                Assert.ThrowsException<DuzaLiteraException>(() =>
                {
                    KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("jan", "kowalski", "12345678901", "jan123", "2000-01-01");
                });
            }

            [TestMethod]
            public void TestZaMlodyUzytkownik()
            {
                Assert.ThrowsException<DuzaLiteraException>(() =>
                {
                    KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("jan", "kowalski", "12345678901", "jan123", "2024-01-01");
                });
            }

            [TestMethod]
            public void TestDodanieWypozyczenia()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Ksiazka", "Autor");

                Wypozyczenie wypozyczenie = new(konto, ksiazka);

                Assert.AreEqual(1, konto.ileWypozyczonych);
            }

            [TestMethod]
            public void TestClone()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");

                KontoBiblioteczne kopia = (KontoBiblioteczne)konto.Clone();

                Assert.AreNotSame(konto, kopia); // Kopia to inny obiekt
                Assert.AreEqual(konto.Imie, kopia.Imie);
                Assert.AreEqual(konto.Nazwisko, kopia.Nazwisko);
                Assert.AreEqual(konto.Pesel, kopia.Pesel);
                Assert.AreEqual(konto.Nazwauzytkownika, kopia.Nazwauzytkownika);
            }

            [TestMethod]
            public void TestEquals_TaSamaNazwaLubPesel()
            {
                KontoBiblioteczne konto1 = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                KontoBiblioteczne konto2 = new KontoBibliotecznePodstawowe("Anna", "Nowak", "12345678901", "jan123", "1990-01-01");

                bool result = konto1.Equals(konto2);

                Assert.IsTrue(result); // Pesel i Nazwauzytkownika s� takie same
            }

            [TestMethod]
            public void Equals_InneNazwaIPesel()
            {
                KontoBiblioteczne konto1 = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                KontoBiblioteczne konto2 = new KontoBibliotecznePodstawowe("Anna", "Nowak", "98765432109", "anna123", "1990-01-01");

                bool result = konto1.Equals(konto2);

                Assert.IsFalse(result); // R�ne Pesel i Nazwauzytkownika
            }

            [TestMethod]
            public void TestCzyWypozyczenieIstnieje()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Wypozyczenie wypozyczenie = new Wypozyczenie(konto, new Ksiazka(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor"));
                konto.listaWypozyczenKonta.Add(wypozyczenie);

                bool result = konto.CzyWypozyczenieIstnieje(wypozyczenie);

                Assert.IsTrue(result);
            }

        }

        [TestClass]
        public class KsiazkaTests
        {
            [TestMethod]
            public void TestTworzenieKsiazki()
            {
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");

                Assert.AreEqual("Tytul", ksiazka.Tytul);
                Assert.AreEqual("Autor", ksiazka.Autor);
                Assert.AreEqual(EnumTypKsiazki.Horror, ksiazka.typKsiazki);
                Assert.AreEqual(EnumWydawnictwo.Czarne, ksiazka.wydawnictwo);
                Assert.IsFalse(ksiazka.czyWypozyczona);
            }

            [TestMethod]
            public void TestNiepoprawnyTytul()
            {
                Assert.ThrowsException<DuzaLiteraException>(() =>
                {
                    Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "tytul", "Autor");
                });
            }

            [TestMethod]
            public void TestCompareToTytul()
            {
                Ksiazka ksiazka1 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul A", "Autor A");
                Ksiazka ksiazka2 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul B", "Autor A");
                Ksiazka.RodzajSortowania = Sortowanie.Tytul;

                int result = ksiazka1.CompareTo(ksiazka2);

                Assert.IsTrue(result < 0); // "Tytul A" jest mniejszy ni� "Tytul B"
            }

            [TestMethod]
            public void TestCompareToAutor()
            {
                Ksiazka ksiazka1 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul A", "Autor A");
                Ksiazka ksiazka2 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul A", "Autor B");
                Ksiazka.RodzajSortowania = Sortowanie.Autor;

                int result = ksiazka1.CompareTo(ksiazka2);

                Assert.IsTrue(result < 0); // "Autor A" jest mniejszy ni� "Autor B"
            }

            [TestMethod]
            public void TestClone()
            {
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");

                Ksiazka kopia = (Ksiazka)ksiazka.Clone();

                Assert.AreNotSame(ksiazka, kopia); // Kopia to inny obiekt
                Assert.AreEqual(ksiazka.Tytul, kopia.Tytul);
                Assert.AreEqual(ksiazka.Autor, kopia.Autor);
                Assert.AreEqual(ksiazka.typKsiazki, kopia.typKsiazki);
                Assert.AreEqual(ksiazka.wydawnictwo, kopia.wydawnictwo);
            }

            [TestMethod]
            public void TestEquals()
            {
                Ksiazka ksiazka1 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Ksiazka ksiazka2 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");

                bool result = ksiazka1.Equals(ksiazka2);

                Assert.IsTrue(result); // Te same tytu�y oznaczaj� r�wno��
            }
        }


        [TestClass]
        public class WypozyczenieTests
        {
            [TestMethod]
            public void TestTworzenieWypozyczenia()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "uzytkownik", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Ksiazka", "Autor");

                Wypozyczenie wypozyczenie = new(konto, ksiazka);

                Assert.AreEqual(1, konto.ileWypozyczonych);
                Assert.IsTrue(ksiazka.czyWypozyczona);
            }

            [TestMethod]
            [ExpectedException(typeof(PoTerminieException))]
            public void PrzedluzTermin_PoDacieZwrotu_RzucaWyjatek()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "uzytkownik", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Ksiazka", "Autor");
                Wypozyczenie wypozyczenie = new(konto, ksiazka, "2023-01-01");

                wypozyczenie.PrzedluzTerminWypozyczenia();
            }

            [TestMethod]
            public void TestWypozyczenieZLimitem()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01") { limitWypozyczen = 1 };
                Ksiazka ksiazka1 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul1", "Autor");
                Ksiazka ksiazka2 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul2", "Autor");
                new Wypozyczenie(konto, ksiazka1);

                Assert.ThrowsException<BladWypozyczenia>(() => new Wypozyczenie(konto, ksiazka2));
            }

            [TestMethod]
            public void TestKsiazkaJestWypozyczona()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor") { czyWypozyczona = true };

                Assert.ThrowsException<BladWypozyczenia>(() => new Wypozyczenie(konto, ksiazka));
            }

            [TestMethod]
            public void TestIlePoTerminie()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Wypozyczenie wypozyczenie = new(konto, ksiazka, "2023-01-01");

                int ilePoTerminie = wypozyczenie.IlePoTerminie();

                Assert.IsTrue(ilePoTerminie > 0);
            }

            [TestMethod]
            public void TestPrzedluzTerminWypozyczenia()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Wypozyczenie wypozyczenie = new(konto, ksiazka);

                DateTime staryTermin = wypozyczenie.dataZwrotu;
                wypozyczenie.PrzedluzTerminWypozyczenia();

                Assert.AreEqual(staryTermin.AddMonths(1), wypozyczenie.dataZwrotu);
            }

            [TestMethod]
            public void TestPrzedluzTerminWypozyczeniaWYJATEK()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Wypozyczenie wypozyczenie = new(konto, ksiazka, "2023-01-01");

                Assert.ThrowsException<PoTerminieException>(() => wypozyczenie.PrzedluzTerminWypozyczenia());
            }

            [TestMethod]
            public void TestWysokoscKary()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Wypozyczenie wypozyczenie = new(konto, ksiazka, "2023-01-01");

                decimal kara = wypozyczenie.WysokoscKary();

                Assert.IsTrue(kara > 0);
            }

            [TestMethod]
            public void TestZwrocKsiazke()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Wypozyczenie wypozyczenie = new(konto, ksiazka);
                wypozyczenie.UregulujNaleznosci();

                wypozyczenie.ZwrocKsiazke();

                Assert.IsFalse(ksiazka.czyWypozyczona);
                Assert.AreEqual(0, konto.ileWypozyczonych);
            }

            [TestMethod]
            public void TestEquals()
            {
                KontoBiblioteczne konto = new KontoBibliotecznePodstawowe("Jan", "Kowalski", "12345678901", "jan123", "2000-01-01");
                Ksiazka ksiazka1 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Ksiazka ksiazka2 = new(EnumTypKsiazki.Horror, EnumWydawnictwo.Czarne, "Tytul", "Autor");
                Wypozyczenie wypozyczenie1 = new(konto, ksiazka1);
                Wypozyczenie wypozyczenie2 = new(konto, ksiazka2);

                bool result = wypozyczenie1.Equals(wypozyczenie2);

                Assert.IsTrue(result);
            }
        }
    }
}