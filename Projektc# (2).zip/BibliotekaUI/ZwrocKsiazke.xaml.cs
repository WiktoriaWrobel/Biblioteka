﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BibliotekaUI
{
    /// <summary>
    /// Logika interakcji dla klasy ZwrocKsiazke.xaml
    /// </summary>
    public partial class ZwrocKsiazke : Window
    {
        private KontoBiblioteczne kontobiblioteczne;
        private Filia filiaBiblioteka;
        public ZwrocKsiazke(KontoBiblioteczne konto, Filia filia)
        {
            InitializeComponent();
            kontobiblioteczne = konto;
            filiaBiblioteka = filia;

            PokazDostepneKsiazki();
        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
            kontoOkno.Show();
            this.Close();
        }

        private void PokazDostepneKsiazki()
        {
            List<Wypozyczenie> dostepneKsiazki = kontobiblioteczne.listaWypozyczenKonta.Where(w => w.WysokoscKary()==0).ToList();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek do zwrotu w tej chwili. Wypożycz książkę lub ureguluj należności.");
            }
            else
            {
                ComboBoxKsiazki.ItemsSource = dostepneKsiazki;
            }
        }

        private void Zwrot(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is Wypozyczenie w)
            {
                w.ZwrocKsiazke();
                kontobiblioteczne.listaWypozyczenKonta.Remove(w);
                MessageBox.Show("Zwrócono książkę");
                KontoUzytkownika kontoOkno = new KontoUzytkownika(kontobiblioteczne, filiaBiblioteka);
                kontoOkno.Show();
                this.Close();
            }
        }
    }
}
