﻿using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Biblioteka;

namespace BibliotekaUI
{

    public partial class MainWindow : Window
    {
        public string CurrentDateTime { get; set; }

        public MainWindow()
        {

            InitializeComponent();
            Filia? warszawa = Filia.OdczytDCXml("Filie/Warszawa");
            Filia? wroclaw = Filia.OdczytDCXml("Filie/Wroclaw");

            Data();
        }

        public void Data()
        {
            CurrentDateTime = DateTime.Now.ToString("yyyy-MM-dd");
            this.DataContext = this;
        }

        private void WyborFilii(object  sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string miasto = selectedItem.Content.ToString();

                switch (miasto)
                {
                    case "Kraków":
                        FiliaKrakow();
                        break;
                    case "Warszawa":
                        FiliaWarszawa();
                        break;
                    case "Wrocław":
                        FiliaWroclaw();
                        break;
                    default:
                        MessageBox.Show("Wybierz miasto.");
                        break;
                }
            }
        }

        private void FiliaKrakow()
        {
            KrakowFilia krakowfilia = new KrakowFilia();
            krakowfilia.Show();
            this.Close();
        }

        private void FiliaWarszawa()
        {
            WarszawaFilia warszawafilia = new WarszawaFilia();
            warszawafilia.Show();
            this.Close();
        }

        private void FiliaWroclaw()
        {
            WroclawFilia wroclawfilia = new WroclawFilia();
            wroclawfilia.Show();
            this.Close();
        }

        private void OtworzStroneInternetowa(object sender, RoutedEventArgs e)
        {
            string url = "https://docs.google.com/document/d/15LPqVYH08-_o3gf92s9CUpEGTt9gjdrEKQszI7dBeaE/edit?usp=sharing"; 

            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas otwierania strony: {ex.Message}");
            }
        }

        private void Pomoc(object sender, RoutedEventArgs e)
        {
            Pomoc pomoc = new Pomoc();
            pomoc.Show();
        }

        


    }
}
