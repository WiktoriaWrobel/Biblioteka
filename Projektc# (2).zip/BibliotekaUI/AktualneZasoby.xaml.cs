﻿using Biblioteka;
using System.Windows;
using System.Windows.Controls;

namespace BibliotekaUI
{
    public partial class AktualneZasoby : Window
    {
        private Filia filiaBiblioteka;
        public AktualneZasoby(Filia filia)
        {
            InitializeComponent();
            filiaBiblioteka = filia;
            PokazDostepneKsiazki();
            PokazDostepneGatunki();
            PokazDostepnychAutorow();
        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PokazDostepneGatunki()
        {
            List<Ksiazka> dostepneKsiazki = filiaBiblioteka.WyszukajKsiazkiDostepne();

            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek w tej chwili!");
            }
            else
            {
                var unikalneGatunki = dostepneKsiazki.Select(k => k.typKsiazki.ToString()).Distinct().OrderBy(g => g).ToList();  
                ComboBoxGatunek.Items.Clear();
                ComboBoxGatunek.ItemsSource = unikalneGatunki;
            }
        }

        private void PokazDostepnychAutorow()
        {
            List<Ksiazka> dostepneKsiazki = filiaBiblioteka.WyszukajKsiazkiDostepne();
            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek w tej chwili.");
            }
            else
            {
                var unikalniAutorzy = dostepneKsiazki.Select(k => k.Autor).Distinct().OrderBy(g => g).ToList();   
                ComboBoxAutorzy.Items.Clear();
                ComboBoxAutorzy.ItemsSource = unikalniAutorzy;
            }
        }

        private void PokazDostepneKsiazki(string gatunek = " ", string autor = " ")
        {
            List<Ksiazka> dostepneKsiazki = filiaBiblioteka.WyszukajKsiazkiDostepne();
            if (dostepneKsiazki.Count == 0)
            {
                MessageBox.Show("Brak dostępnych książek w tej chwili.");
            }
            else
            {
                var filtrowaneKsiazki = dostepneKsiazki.AsEnumerable();
                if (gatunek != " ")
                {
                    filtrowaneKsiazki = filtrowaneKsiazki.Where(k => k.typKsiazki.ToString() == gatunek);
                }
                if (autor != " ")
                {
                    filtrowaneKsiazki = filtrowaneKsiazki.Where(k => k.Autor == autor);
                }
                ListBoxKsiazki.ItemsSource = filtrowaneKsiazki.ToList();
            }
        }

        private void Gatunek(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is string gatunek)
            {
                PokazDostepneKsiazki(gatunek, " ");
            }
        }

        private void Autor(object sender, SelectionChangedEventArgs e)
        {
            if (sender is ComboBox comboBox && comboBox.SelectedItem is string autor)
            {
                PokazDostepneKsiazki(" ", autor);
            }
        }
    }
}
