﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BibliotekaUI
{

    public partial class ZarejestrujSie : Window
    {
        private Filia filiaBiblioteka;

        public ZarejestrujSie(Filia filia)
        {
            InitializeComponent();
            filiaBiblioteka = filia;
        }

        private void Rejestracja(object sender, RoutedEventArgs e)
        {
            string imie = Imie.Text.Trim();
            string nazwisko = Nazwisko.Text.Trim();
            string pesel = Pesel.Text.Trim();
            string nazwaUzytkownika = NazwaUzytkownika.Text.Trim();
            string dataUrodzenia = DataUrodzenia.SelectedDate?.ToString("yyyy-MM-dd") ?? string.Empty;
            bool rodzajKonta = RodzajKonta.IsChecked ?? false;

            KontoBiblioteczne konto;

            if(rodzajKonta)
            {
                konto = new KontoBibliotecznePremium(imie, nazwisko, pesel, nazwaUzytkownika, dataUrodzenia);
                filiaBiblioteka.UtworzKonto(konto);
            }
            else
            {
                konto = new KontoBibliotecznePodstawowe(imie, nazwisko, pesel, nazwaUzytkownika, dataUrodzenia);
                filiaBiblioteka.UtworzKonto(konto);

            }
            MessageBox.Show("Konto zostało utworzone w filli.");
            KontoUzytkownika kontoOkno = new(konto, filiaBiblioteka);
            kontoOkno.Show();
            this.Close();

        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && textBox.Text == textBox.Tag.ToString())
            {
                textBox.Text = string.Empty;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = textBox.Tag.ToString();
            }
        }


    }
}
