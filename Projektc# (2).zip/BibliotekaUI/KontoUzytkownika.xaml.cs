﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;


namespace BibliotekaUI
{

    public partial class KontoUzytkownika : Window
    {
        public string CurrentDateTime { get; private set; }
        private KontoBiblioteczne kontobiblioteczne;
        private Filia filiaBiblioteka;


        public KontoUzytkownika(KontoBiblioteczne konto, Filia filia)
        {
            InitializeComponent();
            Data();
            kontobiblioteczne = konto;
            filiaBiblioteka = filia;

            WyswietlanieDanychUzytkownika();

        }

        public void WyswietlanieDanychUzytkownika()
        {
            ImieNazwiskoTextBlock.Text = $"{kontobiblioteczne.Imie} {kontobiblioteczne.Nazwisko}";
            NazwaUzytkownikaTextBlock.Text = kontobiblioteczne.Nazwauzytkownika;
            if (kontobiblioteczne.limitWypozyczen == 5)
            {
                RodzajKontaTextBlock.Text = "Konto Premium";
            }

            kontobiblioteczne.PokazWypozyczenia();
            List<Wypozyczenie> wypozyczenia = kontobiblioteczne.listaWypozyczenKonta;
            StringBuilder sb = new StringBuilder();
            if(wypozyczenia.Count > 0)
            {
                foreach (Wypozyczenie w in wypozyczenia)
                {
                    sb.AppendLine(w.ToString());
                }
            }
            else
            {
                sb.Append("Brak wypożyczeń w danym momencie.");
            }

            AktualneWypozyczeniaTextBlock.Text = sb.ToString();

        }

        private void Powrot(object sender, RoutedEventArgs e)
        {
            string katalogProjektu = System.IO.Path.GetFullPath(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\.."));
            Directory.SetCurrentDirectory(katalogProjektu);
            string sciezkaWzgledna = $@"Filie\{filiaBiblioteka.NazwaFilii}";
            string sciezkaAbsolutna = System.IO.Path.Combine(Directory.GetCurrentDirectory(), sciezkaWzgledna);
            filiaBiblioteka.ZapisDCXml(sciezkaAbsolutna);
            this.Close();
        }

        public void Data()
        {
            CurrentDateTime = DateTime.Now.ToString("yyyy-MM-dd");
            this.DataContext = this;
        }

        private void WypozyczKsiazke(object sender, RoutedEventArgs e)
        {
            WypozyczKsiazke wypozyczKsiazke = new WypozyczKsiazke(kontobiblioteczne,filiaBiblioteka);
            wypozyczKsiazke.Show();
            this.Close();
        }

        private void PrzedluzTermin(object sender, RoutedEventArgs e)
        {
            PrzedluzTermin przedluzTermin = new(kontobiblioteczne, filiaBiblioteka);
            przedluzTermin.Show();
            this.Close();

        }

        private void UregulujNaleznosc(object sender, RoutedEventArgs e)
        {
            UregulujNaleznosc uregulujNaleznosc = new(kontobiblioteczne, filiaBiblioteka);
            uregulujNaleznosc.Show();
            this.Close();
        }

        private void ZwrocKsiazke(object sender, RoutedEventArgs e)
        {
            ZwrocKsiazke zwrocKsiazke = new(kontobiblioteczne, filiaBiblioteka);
            zwrocKsiazke.Show();
            this.Close();
        }


        
    }
}
