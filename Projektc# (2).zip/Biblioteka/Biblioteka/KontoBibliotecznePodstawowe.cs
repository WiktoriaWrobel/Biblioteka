﻿using Biblioteka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    [DataContract]
    public class KontoBibliotecznePodstawowe : KontoBiblioteczne
    {
        public override decimal StawkaKary => 0.3m;

        public KontoBibliotecznePodstawowe(string imie, string nazwisko, string pesel, string nazwauzytkownika, string dataUrodzenia)
       : base(imie, nazwisko, pesel, nazwauzytkownika, dataUrodzenia)
        {
            limitWypozyczen = 3;
        }

        public override string ToString()
        {
            return base.ToString();
        }

    }
}
