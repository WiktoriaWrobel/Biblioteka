﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Biblioteka
{
    public class DuzaLiteraException : Exception
    {
        public DuzaLiteraException() : base() { }
        public DuzaLiteraException(string message) : base(message) { }
    }


    public enum EnumTypKsiazki {ScienceFiction = 1, Historyczna = 2, Horror = 3, Kryminal = 4, Thriller = 5, Reportaz = 6, Romans = 7}
    public enum EnumWydawnictwo {Znak = 1, Czarne = 20, WydawnictwoAgora = 30, WydawnictwoLiterackie = 40, Muza = 50}
    public enum Sortowanie { Tytul, Autor, AutorTytul }

    [DataContract]
    public class Ksiazka : IComparable<Ksiazka>, ICloneable, IEquatable<Ksiazka>
    {
        [DataMember]
        public EnumTypKsiazki typKsiazki;
        [DataMember]
        public EnumWydawnictwo wydawnictwo;
        [DataMember]
        string tytul;
        [DataMember]
        string autor;
        static int biezacyNumerKsiazki;
        [DataMember]
        int numerKsiazki;
        [DataMember]
        public string kodKsiazki;
        [DataMember]
        public bool czyWypozyczona;
        //[DataMember]
        //DateTime dataZwrotu; //??? czy to jest gdzies uzywane ?????
        // jeśli nie zostanie ustawiony żaden sposób sortowania, domyślnie sortujemy po tytule
        public static Sortowanie RodzajSortowania { get; set; } = Sortowanie.Tytul;
        

        #region wlasciwosci

        public string Tytul
        {
            get => tytul;
            set
            {
                if (!Regex.IsMatch(value, @"^[A-Z]"))
                {
                    throw new DuzaLiteraException("Tytul musi byc napisany z duzej litery");
                }
                tytul = value;
            }
        }
        public string Autor
        {
            get => autor;
            set
            {
                if (!Regex.IsMatch(value, @"^[A-Z]"))
                {
                    throw new DuzaLiteraException("Autor musi byc napisany z duzej litery");
                }
                autor = value;
            }
        }

        internal EnumWydawnictwo Wydawnictwo { get => wydawnictwo; set => wydawnictwo = value; }
        public int NumerKsiazki { get => numerKsiazki; set => numerKsiazki = value; }
        #endregion

        static Ksiazka()
        {
            biezacyNumerKsiazki = 100;
        }

        public Ksiazka(EnumTypKsiazki typKsiazki, EnumWydawnictwo wydawnictwo, string tytul, string autor)
        {
            this.typKsiazki = typKsiazki;
            this.Wydawnictwo = wydawnictwo;
            Tytul = tytul;
            Autor = autor;
            NumerKsiazki = biezacyNumerKsiazki;
            biezacyNumerKsiazki++;
            kodKsiazki = $"{(int)typKsiazki}/{(int)wydawnictwo}/{NumerKsiazki}";
            czyWypozyczona = false;
        }

        public override string ToString()
        {
            string wyp = "dostepna";
            if (czyWypozyczona == true)
            {
                wyp = "ksiazka nie dostepna";
            }
            return $"Tytul: \"{Tytul}\" | Autor: {Autor} ({kodKsiazki})\n{typKsiazki}, {Wydawnictwo} \n{wyp} ";
        }


        public int CompareTo(Ksiazka? other)
        {
            if (other == null) { return 1; }
            switch (RodzajSortowania)
            {
                case Sortowanie.Tytul: 
                    return Tytul.CompareTo(other.Tytul);
                case Sortowanie.Autor: 
                    return Autor.CompareTo(other.Autor);
                case Sortowanie.AutorTytul:
                    int cmp = Autor.CompareTo(other.Autor);
                    if (cmp == 0) 
                    { 
                        cmp = Tytul.CompareTo(other.Tytul); 
                    }
                    return cmp;
                default:
                    return Tytul.CompareTo(other.Tytul);
            }
        }

        public object Clone()
        {
            return MemberwiseClone();
        }

        public bool Equals(Ksiazka? other)
        {
            if (other == null) return false;
            return Tytul == other.Tytul;
        }


    }
}
