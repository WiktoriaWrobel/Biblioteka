﻿using static System.Net.Mime.MediaTypeNames;

namespace Biblioteka
{
    class Program
    {
        public static void Main()
        {
            Ksiazka k1 = new(EnumTypKsiazki.Historyczna, EnumWydawnictwo.Czarne, "Ostrze", "Remigiusz Mroz");
            Ksiazka k2 = new(EnumTypKsiazki.Kryminal, EnumWydawnictwo.WydawnictwoLiterackie, "Raz dwa", "Madera");
            Ksiazka k3 = new(EnumTypKsiazki.Historyczna, EnumWydawnictwo.Znak, "Mieszko I", "Madera");
            
            
            Filia f1 = new("Pegaz");
            f1.DodajKsiazke(k1);
            f1.DodajKsiazke(k2);
            f1.DodajKsiazke(k3);
            //Console.WriteLine(f1);
            List<Ksiazka> ksiazkiHistoryczne = f1.WyszkukajKsiazkiTyp(EnumTypKsiazki.Historyczna);
            foreach(Ksiazka k in ksiazkiHistoryczne)
            {
               // Console.WriteLine(k);
            }
            KontoBibliotecznePodstawowe kbp = new("Zosia", "Ekielska", "12345678990", "zosiae", "2005-12-04");
            //Console.WriteLine(kbp);
            Wypozyczenie w1 = new(kbp, k1, "2024-11-10");
            Wypozyczenie w2 = new(kbp, k2);
            kbp.PokazWypozyczenia();
            //w1.UregulujNaleznosci();
            //w1.ZwrocKsiazke();

            // TESTOWANIE GOSIA!

            f1.UtworzKonto(kbp);

            Ksiazka k4 = new(EnumTypKsiazki.ScienceFiction, EnumWydawnictwo.Muza, "Zielona Mila", "Artur Sikorski");
            Ksiazka k5 = new(EnumTypKsiazki.Romans, EnumWydawnictwo.Czarne, "Lalka", "Bolesław Prus");
            Ksiazka k6 = new(EnumTypKsiazki.Reportaz, EnumWydawnictwo.Znak, "Zdążyć przed Panem Bogiem", "Hanna Krall");
            //Ksiazka k7 = new(EnumTypKsiazki.Reportaz, EnumWydawnictwo.Znak, "Zdążyć przed Panem Bogiem", "Hanna Krall");
            Ksiazka k7 = new(EnumTypKsiazki.Reportaz, EnumWydawnictwo.Znak, "Reportaz", "Hanna Krall");

            Filia f2 = new("Krakow");
            f2.DodajKsiazke(k4);
            f2.DodajKsiazke(k5);
            f2.DodajKsiazke(k6);
            f2.DodajKsiazke(k7);

            f2.UtworzKonto(kbp);

            Propozycja p1 = new("Kryminal", kbp, new() { f1, f2 });
            p1.Proponuj();

            Propozycja p2 = new("Reportaz", kbp, new() { f1, f2 });
            p2.Proponuj();

            //test co jezeli nie ma konta w zadnej filii 
            KontoBibliotecznePodstawowe kbp2 = new("Malgorzata", "Gdowska", "12345678990", "gosia", "2004-12-04");

            Propozycja p3 = new("Reportaz", kbp2, new() { f1, f2 });
            p3.Proponuj();

            Console.WriteLine(f1);
            f1.SortujKsiazkiPoTytule();
            Console.WriteLine(f1);

            //f1.SortujKsiazkiPoAutorze();
            //Console.WriteLine(f1);

            Console.WriteLine(f2);
            f2.SrotujKsiazkiPoAutorzeITytule();
            Console.WriteLine(f2);

            //f1.ZapisDCXml("Pegaz");

            Filia filiaDODUPLIKATU = new Filia("Filia Kraków");

            Ksiazka ksiazka1 = new Ksiazka(EnumTypKsiazki.Historyczna, EnumWydawnictwo.Znak, "Historia Polski", "Jan Nowak");
            Ksiazka ksiazka2 = new Ksiazka(EnumTypKsiazki.Historyczna, EnumWydawnictwo.Znak, "Historia Polski", "Jan Nowak"); // Duplikat

            KontoBibliotecznePremium kp = new("Zosia", "Ekielska", "12345678990", "zosiae", "2005-12-04");
            KontoBibliotecznePremium kpDUPLIKAT = new("Zosia", "Ekielska", "12345678991", "zosiae", "2005-12-04");

            filiaDODUPLIKATU.DodajKsiazke(ksiazka1);
            filiaDODUPLIKATU.DodajKsiazke(ksiazka2);

            filiaDODUPLIKATU.UtworzKonto(kp);
            filiaDODUPLIKATU.UtworzKonto(kpDUPLIKAT);

            Console.WriteLine(filiaDODUPLIKATU.ListaKont.Count); //  2 powinno wyjsc 


            filiaDODUPLIKATU.UsunDuplikatyKont();

            Console.WriteLine(filiaDODUPLIKATU.ListaKont.Count); //  1 powinno wyjsc 

            bool istnieje = filiaDODUPLIKATU.CzyKsiazkaIstnieje(ksiazka1);
            Console.WriteLine(istnieje ? "Książka istnieje." : "Książka nie istnieje.");

            Wypozyczenie wypozyczenie = new Wypozyczenie(kbp, ksiazka1);
            bool istniejeWypozyczenie = kbp.CzyWypozyczenieIstnieje(wypozyczenie);

            Console.WriteLine(istniejeWypozyczenie ? "Wypożyczenie istnieje." : "Brak wypożyczenia.");

            bool istniejekonto = filiaDODUPLIKATU.CzyKontoIstnieje(kbp);
            Console.WriteLine(istniejekonto ? "Konto istnieje w filii." : "Konto nie istnieje w filii.");

            //TESTOWANIE DELEGATÓW FILTRACJI KONT

            List<KontoBiblioteczne> kontaZPrzekroczonymLimitem = f1.FiltrujKonta(k => k.ileWypozyczonych > k.limitWypozyczen);
            kontaZPrzekroczonymLimitem.ForEach(k => Console.WriteLine($"Konto: {k.Nazwauzytkownika}, Wypożyczone: {k.ileWypozyczonych}/{k.limitWypozyczen}"));

            List<KontoBiblioteczne> kontaBezWypozyczen = f1.FiltrujKonta(k => k.ileWypozyczonych == 0);
            kontaBezWypozyczen.ForEach(k => Console.WriteLine($"Konto: {k.Nazwauzytkownika} nie ma wypożyczeń."));

            List<KontoBiblioteczne> kontaPremium = f1.FiltrujKonta(k => k is KontoBibliotecznePremium);
            kontaPremium.ForEach(k => Console.WriteLine($"Konto premium: {k.Nazwauzytkownika}."));

            //TESTOWANIE DELEGATÓW FILTRACJI KSIAZEK

            List<Ksiazka> ksiazkiAgathyChristie = f2.WyszukajKsiazki(k => k.Autor == "Agatha Christie");
            if(!ksiazkiAgathyChristie.Any())
            {
                Console.WriteLine("Brak książek Agaty Christie w filii.");
            }
            ksiazkiAgathyChristie.ForEach(k => Console.WriteLine($"Tytuł: {k.Tytul}, Autor: {k.Autor}"));

            List<Ksiazka> historyczneKsiazki = f1.WyszukajKsiazki(k => k.typKsiazki == EnumTypKsiazki.Historyczna);
            historyczneKsiazki.ForEach(k => Console.WriteLine($"Tytuł: {k.Tytul}, Gatunek: {k.typKsiazki}"));

            List<Ksiazka> ksiazkiZeSłowemHistoria = f1.WyszukajKsiazki(k => k.Tytul.Contains("Historia"));
            ksiazkiZeSłowemHistoria.ForEach(k => Console.WriteLine($"Tytuł: {k.Tytul}, Autor: {k.Autor}"));

            //delegaty zdarzenia 

            f1.DodanoKsiazke += ksiazka => Console.WriteLine($"Dodano nową książkę: \"{ksiazka.Tytul}\", Autor: {ksiazka.Autor}");
            f2.DodanoKonto += konto => Console.WriteLine($"Dodano nowe konto użytkownika: {konto.Nazwauzytkownika}");

            Console.WriteLine(f1);

            Console.WriteLine(kbp.limitWypozyczen);
            Console.WriteLine(kbp.StawkaKary);

            //KontoBibliotecznePremium kpremium = new("gosia", "gdowska", "90", "lol", "1999-12-12");

            f2.ZapisDCXml("Krakow");
        }
    }

}
