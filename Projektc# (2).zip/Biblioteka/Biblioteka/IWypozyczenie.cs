﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteka
{
    internal interface IWypozyczenie
    {
        int IlePoTerminie();

        void PrzedluzTerminWypozyczenia();
        public decimal WysokoscKary();
        void UregulujNaleznosci();
        void ZwrocKsiazke();

    }
}
